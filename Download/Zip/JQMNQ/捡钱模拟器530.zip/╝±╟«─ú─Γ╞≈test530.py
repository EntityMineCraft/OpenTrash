﻿#虽然这一目了然，但我还要加注释：以下是导入
import random
import time
#虽然这一目了然，但我还要加注释：以下是变量
MB = random.randint(0,922337)
bMB = random.randint(0,2147483)
RT = ['要捡到5kw彩票就好了', '真走运', '卧槽牛逼', '？？？？', 'woc!!!', '卧槽', 'WTF?']
RTS = random.sample(RT, 1)
#虽然这一目了然，但我还要加注释：以下是输出文本
print('test',9223372036854775807+1,)
print('Run at',time.asctime())
print('---捡钱模拟器Ver5.3.0(test)---')
print('捡钱模拟器赞助：')
print('开发商：CI工作室')
print('开发者：Entity')
print('语言：python')
print('文本编辑器：VSCode、QPython')
print('野生前(美)端(工)工程师优(劣)秀(质)产物')
print('----------------------')
input('Enter拾钱')
print(time.strftime("*** 在%Y年%m月%d日%H点%M分%S秒那天"))
print('*** 你捡到支票和欠条了! 拿到了',bMB,'支票和',MB,'欠条!')
print('*** 你获得了 钱',bMB-MB)
print(RTS)
print('你把',bMB-MB,'元存进了银行卡')
print('你和你的plmm过上了没羞没噪的生活')
print('ah that’s♂good')
input('')