﻿#The file by CI Studio™
#作者：Entity 
#成员：任之炼 
#答疑：FFS、Ninecloud...
import random
import time
MB = random.randint(0,922337)
gMB = random.randint(0,2147483)
RT = ['要捡到5kw彩票就好了', '真走运', '卧槽牛逼', '？？？？', 'woc!!!', '卧槽', 'WTF?']
RTS = random.sample(RT, 1)
print('test',9223372036854775807+1,)
print('Run at',time.asctime())
print('---捡钱模拟器Ver5.7.3(test)---')
print('捡钱模拟器赞助：')
print('开发商：CI工作室')
print('开发者：Entity')
print('语言：python')
print('文本编辑器：VSCode、QPython、')
print('CEdit（kolibriOS）、notepad')
print('野生前(美)端(工)工程师优(劣)秀(质)产物')
print('----------------------')
input('Enter拾钱')
print(time.strftime("*** 在%Y年%m月%d日%H点%M分%S秒那天"))
print('*** 你捡到支票和欠条了! 拿到了',gMB,'支票和',MB,'欠条!')
print('*** 你获得了 钱',gMB-MB)
print(RTS)
TorF = random.randint(0,1)
badtime = random.randint(3,7)
if gMB-MB => 100000
{
    print('你进了监狱，因为你捡巨款不上交')
    if TorF == 0
    {
        print('你被假释了')
        print('你和你的plmm过上了没羞没噪的生活')
        print('ah that’s♂good')
    }
    else
    {
        print('你被判了',badtime,'年的有期徒刑')
    }
}
else
{
    print('你把',gMB-MB,'存进了银行卡')
    print('你的小♂日子过得挺不错')
}
input('')